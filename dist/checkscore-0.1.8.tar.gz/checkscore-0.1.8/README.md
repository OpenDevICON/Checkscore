# Checkscore
This repository contains the utilities for Checkscore package for faster testing of SCORE methods through Jupyter Notebook approach.